package patterns.observable;

import java.util.ArrayList;

public class Stock {

	private String stockCode;
	private double stockPrice;
	private ArrayList<StockListener> listeners = new ArrayList<StockListener>();
	
	Stock(String code, double price){
		this.stockCode = code;
		this.stockPrice = price;
	}
	
	public void setPrice(double newPrice) {
		for(StockListener sl : listeners) {
			sl.stockPriceChanged(this, stockPrice, newPrice);
		}
		this.stockPrice = newPrice;
	}
	
	public String getTicker() {
		return stockCode;
	}
	
	public double getPrice() {
		return stockPrice;
	}
	
	public void addStockListener(StockListener sl) {
		listeners.add(sl);
	}
	
	public void removeStockListener(StockListener sl) {
		listeners.remove(sl);
	}
	
	
	
}
