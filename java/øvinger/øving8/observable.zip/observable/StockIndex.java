package patterns.observable;

import java.util.ArrayList;

public class StockIndex implements StockListener{

	private String name;
	private double indeks;
	private ArrayList<Stock> stocks = new ArrayList<Stock>();
	
	StockIndex(String name, Stock... stocks){
		this.name = name;
		for(Stock s : stocks) {
			this.stocks.add(s);
			this.indeks += s.getPrice();
		}
		
	}

	public void addStock(Stock s) {
		if(!stocks.contains(s)) {
			stocks.add(s);
			this.indeks = getIndex();
		}

	}
	
	public void removeStock(Stock s) {
		this.indeks -= s.getPrice();
		stocks.remove(s);
	}
	
	public double getIndex() {
		double temp = 0;
		for(Stock s : stocks) {
			temp += s.getPrice();
		}
		return temp;
	}
	
	@Override
	public void stockPriceChanged(Stock stock, double oldValue, double newValue) {
		this.indeks = getIndex();
	}
	
	public static void main(String[] args) {
		Stock facebook = new Stock("OSBX", 69.87);
		StockIndex gay = new StockIndex("OXBSB");
		gay.addStock(facebook);
		gay.addStock(facebook);
		gay.removeStock(facebook);
		System.out.println(gay.getIndex());
	}
	
}
